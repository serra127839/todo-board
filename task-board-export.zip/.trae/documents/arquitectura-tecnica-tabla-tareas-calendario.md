## 1. Diseño de Arquitectura

```mermaid
flowchart LR
  U["Usuarios (Navegador)"] --> FE["Frontend (React + Vite)"]
  FE --> API["Backend API (Express)"]
  FE <--> WS["Canal tiempo real (WebSocket)"]
  API --> DB["Base de datos (SQLite)"]
  WS --> API
```

## 2. Descripción de Tecnologías
- Frontend: React@18 + TypeScript + vite
- Estilos: tailwindcss@3 (tema pastel + utilidades) + CSS para detalles finos
- Realtime: ws (WebSocket)
- Backend: Express@4
- Base de datos: SQLite (archivo local) + migraciones simples
- Servido: el backend sirve los estáticos del build del frontend en producción

## 3. Definición de Rutas
| Ruta | Propósito |
|------|-----------|
| / | Tablero principal |

## 4. Definición de APIs (Backend)

### 4.1 Tipos (TypeScript)
```ts
export type CellStatus = "red" | "yellow" | "green" | "black";

export type CellValue = {
  percent: 0 | 25 | 50 | 75 | 100;
  status: CellStatus;
};

export type TaskRow = {
  id: string;
  title: string;
  owner: string;
  order: number;
};

export type Board = {
  id: string;
  startDate: string;
  endDate: string;
};
```

### 4.2 REST
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | /api/board | Devuelve configuración (rango de fechas) y filas |
| POST | /api/tasks | Crea una tarea |
| PATCH | /api/tasks/:id | Edita título/responsable/orden |
| POST | /api/tasks/:id/duplicate | Duplica una tarea (sin copiar celdas o copiándolas, configurable) |
| DELETE | /api/tasks/:id | Elimina una tarea |
| PUT | /api/cells | Upsert de celda (taskId + date) con percent/status |
| GET | /api/export | Exporta JSON del tablero |
| POST | /api/import | Importa JSON del tablero (reemplaza o merge, configurable) |

### 4.3 WebSocket (tiempo real)
Mensajes JSON (simplificado):
- `server:hello`: estado inicial (board + tasks + celdas) si no se cargó por REST.
- `cell:updated`: `{ taskId, date, value, updatedAt }`
- `task:created|updated|deleted|reordered`
- `presence:changed` (opcional): usuarios conectados.

Estrategia de conflictos (MVP):
- Última escritura gana (por `updatedAt` del servidor).

## 5. Diagrama de Arquitectura del Servidor

```mermaid
flowchart TD
  R["Router (Express)"] --> C["Controllers"]
  C --> S["Services"]
  S --> REPO["Repositories"]
  REPO --> DB["SQLite"]
  S --> HUB["Realtime Hub (WS)"]
  HUB --> CLIENTS["Clientes conectados"]
```

## 6. Modelo de Datos

### 6.1 Definición (ER)
```mermaid
erDiagram
  BOARDS ||--o{ TASKS : "tiene"
  TASKS ||--o{ CELLS : "tiene"

  BOARDS {
    text id PK
    text start_date
    text end_date
  }

  TASKS {
    text id PK
    text board_id FK
    text title
    text owner
    integer sort_order
    text created_at
    text updated_at
  }

  CELLS {
    text task_id FK
    text date
    integer percent
    text status
    text updated_at
  }
```

### 6.2 DDL (SQLite)
```sql
CREATE TABLE IF NOT EXISTS boards (
  id TEXT PRIMARY KEY,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  board_id TEXT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  owner TEXT NOT NULL,
  sort_order INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cells (
  task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  percent INTEGER NOT NULL,
  status TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (task_id, date)
);

CREATE INDEX IF NOT EXISTS idx_tasks_board_order ON tasks(board_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_cells_date ON cells(date);
```
