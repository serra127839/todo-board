## 1. Visión General del Producto
Aplicación web colaborativa para seguimiento diario de tareas en una tabla tipo calendario (3 semanas: lunes 13/04/2026 → jueves 30/04/2026).
- Permite registrar avance (0–100%) y estado semáforo por día y por tarea, con interacción directa por ratón.
- Orientada a coordinación rápida con cliente y equipo técnico, con cambios sincronizados entre varios usuarios.

## 2. Funcionalidades Principales

### 2.1 Roles de Usuario
| Rol | Método de acceso | Permisos principales |
|-----|------------------|----------------------|
| Editor | Enlace a tablero (sin registro en MVP) | Crear/editar/mover/duplicar/eliminar tareas, editar celdas, exportar/importar |
| Lector | Enlace a tablero en modo lectura (opcional) | Ver tablero y cambios en tiempo real |

### 2.2 Módulos de Funcionalidad
1. **Tablero (Tabla calendario)**: columnas de fecha, filas de tareas, scroll horizontal, cabeceras y primeras columnas fijas.
2. **Edición de celdas**: avance por tramos (0/25/50/75/100) con click izquierdo; estado semáforo con click derecho.
3. **Gestión de filas**: crear, editar título/responsable, mover (arrastrar), duplicar, eliminar.
4. **Colaboración multiusuario**: sincronización de cambios en tiempo real, presencia (usuarios conectados) opcional.
5. **Persistencia y portabilidad**: guardado en servidor; exportar/importar JSON del tablero.

### 2.3 Detalle por Página
| Página | Módulo | Descripción de funcionalidad |
|--------|--------|------------------------------|
| Tablero | Encabezado | Selector/visualización de rango de fechas (fijo en MVP), botón “Nueva tarea”, exportar/importar, indicador de conexión |
| Tablero | Tabla | 2 columnas fijas (Tarea, Responsable técnico) + columnas diarias; edición directa y estados visuales |
| Tablero | Gestión filas | Menú por fila (duplicar/eliminar) + arrastrar para reordenar |
| Tablero | Colaboración | Actualización en tiempo real de celdas/filas; resolución simple de conflictos (última escritura gana) |

## 3. Proceso Principal
Flujo de usuario:
1. Abre el enlace del tablero.
2. Crea una tarea y asigna responsable técnico.
3. En cada día, hace click izquierdo para fijar avance por tramos; click derecho para rotar estado semáforo.
4. Reordena tareas arrastrando filas; duplica/elimina según necesidad.
5. Cambios se guardan y se reflejan en otros usuarios conectados.

```mermaid
flowchart TD
  A["Abrir enlace del tablero"] --> B["Cargar datos desde servidor"]
  B --> C["Renderizar tabla calendario"]
  C --> D["Editar celda (avance/estado)"]
  C --> E["Gestionar fila (crear/mover/duplicar/eliminar)"]
  D --> F["Enviar cambio al servidor"]
  E --> F
  F --> G["Guardar en base de datos"]
  G --> H["Emitir actualización a usuarios conectados"]
  H --> C
```

## 4. Diseño de Interfaz de Usuario

### 4.1 Estilo de Diseño
- Paleta: fondo claro cálido + acentos pastel; semáforo (rojo/amarillo/verde/negro) con tonos suavizados y bordes discretos.
- Indicador de avance: símbolo circular elegante por celda (anillo/progreso radial) con número opcional al pasar el ratón.
- Tipografía: combinación editorial (título) + lectura clara (cuerpo), evitando tipografías genéricas.
- Layout: denso pero legible; rejilla con separadores finos, esquinas suaves, micro-animaciones sutiles.
- Iconografía: minimalista (líneas finas), sin emojis en UI principal.

### 4.2 Resumen de Diseño por Módulo
| Página | Módulo | Elementos UI |
|--------|--------|--------------|
| Tablero | Encabezado | Barra superior con título, fecha de referencia, botones “Nueva tarea”, “Exportar”, “Importar”, estado de conexión |
| Tablero | Tabla | Cabecera sticky de fechas; dos primeras columnas sticky; celdas con indicador circular pastel y color de estado |
| Tablero | Edición | Click izquierdo: bucle avance; click derecho: bucle estado; feedback visual inmediato + animación suave |

### 4.3 Responsive
Desktop-first.
- En pantallas pequeñas: scroll horizontal/vertical, botones compactos, opción de ocultar/mostrar columna “Responsable técnico”.
